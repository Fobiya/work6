// JS import all in JS
//import './jquery.min.js';

//import './send.js';
//import './send.js';


//import './jquery-3.2.1.min.js';



import './common.js';

//import './compress.js';

import './slick.min.js';
//import './jquery.maskedinput.min.js';
//import './lazyload.min.js'; 
//import './lazysizes.min.js'; 
//import './jquery.fancybox.min.js';